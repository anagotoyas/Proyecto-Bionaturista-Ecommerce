package com.bionaturista.application.dto.producto;
import com.bionaturista.domain.entities.Categoria;
import com.bionaturista.domain.entities.Compuesto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Getter
@Setter
@ToString
public class ProductoDto {

    Integer idProducto;
    String nombreP;
    String imagenP;
    String descripcionP;
    int precioP;
    Integer stockP;


    Compuesto compuesto;
    Categoria categoria;
}
