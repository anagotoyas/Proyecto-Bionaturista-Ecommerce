package com.bionaturista.application.controllers;

import com.bionaturista.application.dto.categoria.RespuestaCategoria;
import com.bionaturista.application.dto.categoria.RespuestaCategoriaEntity;
import com.bionaturista.application.dto.compuesto.RespuestaCompuestoEntity;
import com.bionaturista.application.dto.producto.ProductoDto;
import com.bionaturista.application.dto.producto.RespuestaProducto;
import com.bionaturista.application.dto.producto.RespuestaProductoEntity;
import com.bionaturista.domain.entities.Categoria;
import com.bionaturista.domain.entities.Compuesto;
import com.bionaturista.domain.entities.Producto;
import com.bionaturista.domain.services.ProductoService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    protected final Log logger = LogFactory.getLog(getClass());




    @Autowired
    private ProductoService productoService;

    @PostMapping(value="/tuvieja", produces = {"application/json"}, consumes = {"application/json"})
    public ResponseEntity<RespuestaProductoEntity> crearProducto(@RequestBody ProductoDto producto){

        RespuestaProductoEntity res = new RespuestaProductoEntity();


        try {

            res.setSatisfactorio(true);
            res.setCodigo("101");
            res.setMensaje("aaaaaaaaa");
            System.out.println(res);
            Producto producto1 = productoService.crearProducto(producto);
            System.out.println("perra" +res+ producto1);

            res.setData(producto1);

            if (res.isSatisfactorio() == true){
                return new ResponseEntity<RespuestaProductoEntity>(res, HttpStatus.OK);
            }

            else {
                return new ResponseEntity<RespuestaProductoEntity>(res, HttpStatus.BAD_REQUEST);
            }

        } catch(InterruptedException e){
            RespuestaProductoEntity respuesta = new RespuestaProductoEntity();
            respuesta.setSatisfactorio(false);
            respuesta.setCodigo("109");
            respuesta.setMensaje("aaa" + e.getMessage());
            return new ResponseEntity<>(respuesta,HttpStatus.INTERNAL_SERVER_ERROR);
        }
        catch(Exception e){
            RespuestaProductoEntity respuesta = new RespuestaProductoEntity();
            respuesta.setSatisfactorio(false);
            respuesta.setCodigo("109");
            respuesta.setMensaje(e.getMessage());
            return new ResponseEntity<>(respuesta,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping(value="/listar", produces = {"application/json"})
    public ResponseEntity<RespuestaProducto> listarProductos() {

        RespuestaProducto res= new RespuestaProducto();
        System.out.println(res);

        try {

            res.setSatisfactorio(true);
            res.setCodigo("101");
            res.setMensaje("Yupi");

            List<Producto> lista = productoService.listarProducto();

            res.setData(lista);
            System.out.println(res);
            return new ResponseEntity<>(res, HttpStatus.OK);

        }
        catch(InterruptedException e){
            res.setSatisfactorio(false);
            res.setCodigo("109");
            res.setMensaje("Lloro" + e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        catch(Exception e){

            res.setSatisfactorio(false);
            res.setCodigo("109");
            res.setMensaje(e.getMessage());
            return new ResponseEntity<>(res,HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
}
