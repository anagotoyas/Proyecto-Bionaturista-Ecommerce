package com.bionaturista.application.dto.compuesto;

import com.bionaturista.application.dto.producto.ProductoDto;
import com.bionaturista.domain.entities.Producto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.OneToMany;
import java.util.List;

@Getter
@Setter
@ToString
public class CompuestoDto {

    Integer idCompuesto;
    String nombreCompuesto;

    List<Producto> producto;

}
