package com.bionaturista.domain.services.impl;


import com.bionaturista.application.dto.categoria.CategoriaDto;
import com.bionaturista.application.dto.producto.ProductoDto;
import com.bionaturista.application.dto.producto.RespuestaProductoEntity;
import com.bionaturista.application.dto.respuestas.Respuesta;
import com.bionaturista.domain.entities.Categoria;
import com.bionaturista.domain.entities.Producto;
import com.bionaturista.domain.repositories.ProductoRepository;
import com.bionaturista.domain.services.ProductoService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductoServiceImpl implements ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    protected final Log logger = LogFactory.getLog(getClass());
    @Value("${service.producto}")
    String serviceProducto;

    @Override
    public Producto crearProducto(ProductoDto producto)  throws InterruptedException{


        Producto producty = new Producto();
        producty.setNombreP(producto.getNombreP());
        producty.setImagenP(producto.getImagenP());
        producty.setDescripcionP(producto.getDescripcionP());
        producty.setPrecioP(producto.getPrecioP());
        producty.setStockP(producto.getStockP());
        producty.setCategoria(producto.getCategoria());
        producty.setCompuesto(producto.getCompuesto());

        System.out.println(producty);

        Producto productynew = productoRepository.save(producty);

        System.out.println(productynew);

        HttpEntity<Producto> entity = new HttpEntity<>(productynew);
        RestTemplate restTemplate=new RestTemplate();

        ResponseEntity<RespuestaProductoEntity> response = restTemplate.exchange(serviceProducto, HttpMethod.POST, entity,
                new ParameterizedTypeReference<RespuestaProductoEntity>() {
                });
        System.out.println(productynew);
        RespuestaProductoEntity respuesta = new RespuestaProductoEntity();

        if (response.getStatusCode() == HttpStatus.CREATED) {
            return productynew;
        }

        else {
            logger.error("Error en la respuesta del servicio invocado. Code:" + response.getStatusCode());
            throw new InterruptedException("Error en la respuesta del servicio invocado. Code:" + response.getStatusCode());
        }
    }

    @Override
    public Producto modificarProducto(ProductoDto producto) throws InterruptedException {
        return null;
    }

    @Override
    public Respuesta eliminarProducto(Integer idProducto) throws InterruptedException {
        return null;
    }

    @Override
    public List<Producto> listarProducto() throws InterruptedException {
        RestTemplate restTemplate=new RestTemplate();

        ResponseEntity<List<ProductoDto>> response = restTemplate.exchange(serviceProducto,HttpMethod.GET, null,
                new ParameterizedTypeReference<List<ProductoDto>>() {
                });

        List<Producto> lista = new ArrayList<>();
        Producto producto;

        if(response.getStatusCode()==HttpStatus.OK)

        {
            for (ProductoDto item : response.getBody()) {
                producto = new Producto();
                producto.setNombreP(item.getNombreP());
                producto.setIdProducto(item.getIdProducto());
                producto.setCategoria(item.getCategoria());
                producto.setCompuesto(item.getCompuesto());
                producto.setStockP(item.getStockP());
                producto.setPrecioP(item.getPrecioP());
                producto.setImagenP(item.getImagenP());
                producto.setDescripcionP(item.getDescripcionP());

                lista.add(producto);

            }
            return lista;
        }
        else
        {
            logger.error("Error en la respuesta del servicio invocado. Code:" + response.getStatusCode());
            throw new InterruptedException("Error en la respuesta del servicio invocado. Code:" + response.getStatusCode());
        }
    }

    @Override
    public Producto obtenerProductoPorIdProducto(Integer idProducto) throws InterruptedException {
        return null;
    }

    @Override
    public Long countProductos() throws InterruptedException {
        return null;
    }

    @Override
    public List<Producto> buscarPorNombre(String nombreP) throws InterruptedException {
        return null;
    }
}
