package com.bionaturista.domain.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Getter
@Setter
@ToString
@Table(name="productos")
public class Producto {

    @Id
    @JsonProperty("idProducto")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
     Integer idProducto;

    @NotNull
    @JsonProperty("nombre_producto")
    @Size(min = 2, max = 70, message = "El nombre del producto debe tener como mínimo 2 caracteres")
    @Column(name="nombre_producto", nullable = false, length = 70)
     String nombreP;

    @JsonProperty("imagen_producto")
    @Column(name="imagen_producto")
     String imagenP;

    @JsonProperty("descripcion_producto")
    @Column(name="descripcion_producto")
     String descripcionP;

    @NotNull
    @JsonProperty("precio_producto")
    @Column(name="precio_producto")
     float precioP;

    @NotNull
    @JsonProperty("stock_producto")
    @Column(name="stock_producto")
     int stockP;

    @ManyToOne
    @JsonProperty("id_compuesto")
    @JoinColumn(name = "id_compuesto", nullable = false,
            foreignKey = @ForeignKey(name = "FK_id_compuesto"))
    private Compuesto compuesto;

    @ManyToOne
    @JsonProperty("id_categoria")
    @JoinColumn(name = "id_categoria", nullable = false,
            foreignKey = @ForeignKey(name = "FK_id_categoria"))
    private Categoria categoria;

}
