package com.bionaturista.domain.repositories;

import com.bionaturista.domain.entities.InfoEnvio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InfoEnvioRepository extends JpaRepository<InfoEnvio, Integer> {


}
