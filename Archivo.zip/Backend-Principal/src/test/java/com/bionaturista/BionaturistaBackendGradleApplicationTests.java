package com.bionaturista;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BionaturistaBackendGradleApplicationTests {

    @Test
    void contextLoads() {
    }

}
